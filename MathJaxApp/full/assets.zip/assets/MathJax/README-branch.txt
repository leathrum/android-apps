This is release branch v2.0 of MathJax.
